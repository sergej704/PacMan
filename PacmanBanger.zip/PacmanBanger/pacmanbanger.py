import pygame
import sys
import random
import math

# Initialisiere Pygame
pygame.init()

# Bildschirmgröße und Farben
CHAR_SIZE = 32
MAP = [
    ['1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1'],
    ['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
    ['1','B','1','1',' ','1','1','1',' ','1',' ','1','1','1',' ','1','1','B','1'],
    ['1',' ',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ',' ','1'],
    ['1','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1',' ','1','1'],
    ['1',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ',' ','1',' ',' ','1'],
    ['1',' ','1','1','1','1',' ','1','1','1','1','1',' ','1','1','1','1',' ','1'],
    ['1',' ',' ',' ',' ',' ',' ',' ',' ','r',' ',' ',' ',' ',' ',' ',' ',' ','1'],
    ['1','1',' ','1','1','1',' ','1','1','-','1','1',' ','1','1','1',' ','1','1'],
    ['1',' ',' ',' ',' ','1',' ','1','s','W','o','1',' ','1',' ',' ',' ',' ','1'],
    ['1','1',' ','1',' ','1',' ','1','1','1','1','1',' ','1',' ','1',' ','1','1'],
    ['1',' ',' ','1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1',' ',' ','1'],
    ['1',' ','1','1','1','1',' ','1','1','1','1','1',' ','1','1','1','1',' ','1'],
    ['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
    ['1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1'],
    ['1',' ',' ',' ','1',' ',' ',' ',' ','P',' ',' ',' ',' ','1',' ',' ',' ','1'],
    ['1','B','1',' ','1',' ','1',' ','1','1','1',' ','1',' ','1',' ','1','B','1'],
    ['1',' ','1',' ',' ',' ','1',' ',' ',' ',' ',' ','1',' ',' ',' ','1',' ','1'],
    ['1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1','1','1',' ','1'],
    ['1',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','1'],
    ['1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1']
]

MAP_RATIO = (len(MAP[0]), len(MAP))
WIDTH, HEIGHT = (MAP_RATIO[0] * CHAR_SIZE, MAP_RATIO[1] * CHAR_SIZE)

# Initialisiere das Spielfeld
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pacman")

# Farben
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
PINK = (255, 105, 180)

# Level-Design
level = [
    [2 if cell == '1' else 1 if cell == ' ' else 0 for cell in row]
    for row in MAP
]

# Pacman
pacman_pos = [1, 1]  # Spieler oben in der Mitte
pacman_speed = [0, 0]

def get_random_direction():
    return random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)])

# Gegner-Verwaltung
NUM_ENEMIES = 4  # Blinky, Inky, Pinky, Clyde
center_x, center_y = MAP_RATIO[0] // 2, MAP_RATIO[1] // 2

# Gegner-KI-Funktionen
def calculate_direction_to_pacman(enemy_pos):
    dx = pacman_pos[0] - enemy_pos[0]
    dy = pacman_pos[1] - enemy_pos[1]

    if abs(dx) > abs(dy):
        if dx > 0:
            return (1, 0)
        elif dx < 0:
            return (-1, 0)
    else:
        if dy > 0:
            return (0, 1)
        elif dy < 0:
            return (0, -1)

    if dx > 0 and dy > 0:
        return (1, 1)
    elif dx > 0 and dy < 0:
        return (1, -1)
    elif dx < 0 and dy > 0:
        return (-1, 1)
    elif dx < 0 and dy < 0:
        return (-1, -1)

def enemy_AI(enemy, mode='chase'):
    if mode == 'chase':
        return calculate_direction_to_pacman(enemy["pos"])
    elif mode == 'scatter':
        return get_random_direction()
    elif mode == 'ambush':
        return get_random_direction() if random.random() > 0.5 else calculate_direction_to_pacman(enemy["pos"])

enemy_positions = [
    (center_x, center_y),  
    (center_x - 1, center_y),  
    (center_x + 1, center_y),  
    (center_x, center_y + 1)  
]

enemies = [
    {"pos": list(enemy_positions[0]), "mode": 'chase', "color": RED},  
    {"pos": list(enemy_positions[1]), "mode": 'scatter', "color": GREEN},  
    {"pos": list(enemy_positions[2]), "mode": 'ambush', "color": PINK},  
    {"pos": list(enemy_positions[3]), "mode": 'scatter', "color": BLUE},  
]

# Pacman-Animation
def scale_sprite(image, size):
    return pygame.transform.scale(image, (size, size))

pacman_sprites = {
    "up": [
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthOpenUP.png"), CHAR_SIZE),
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthHalfOpenUP.png"), CHAR_SIZE),
    ],
    "down": [
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthOpendown.png"), CHAR_SIZE),
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthHalfOpenDOWN.png"), CHAR_SIZE),
    ],
    "left": [
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthOpenLEFT.png"), CHAR_SIZE),
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthHalfOpenLEFT.png"), CHAR_SIZE),
    ],
    "right": [
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthOpen.png"), CHAR_SIZE),
        scale_sprite(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/PacmanMouthHalfOpen.png"), CHAR_SIZE),
    ],
}

enemy_sprites = {
    "up": pygame.transform.scale(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/GhostUp.png"), (CHAR_SIZE, CHAR_SIZE)),
    "down": pygame.transform.scale(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/GhostDown.png"), (CHAR_SIZE, CHAR_SIZE)),
    "left": pygame.transform.scale(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/GhostLeft.png"), (CHAR_SIZE, CHAR_SIZE)),
    "right": pygame.transform.scale(pygame.image.load("C:/Schule/PO/pacman/PacManSprites/GhostRight.png"), (CHAR_SIZE, CHAR_SIZE))
}

# Richtung des Gegners für die Animation setzen
def get_enemy_facing(enemy_direction):
    if enemy_direction == (0, -1):
        return "up"
    elif enemy_direction == (0, 1):
        return "down"
    elif enemy_direction == (-1, 0):
        return "left"
    elif enemy_direction == (1, 0):
        return "right"

# Funktion für das Hauptmenü
def main_menu():
    # Starte Musik im Hauptmenü
    pygame.mixer.music.load("C:/Schule/PO/pacman/lobbymusic.mp3")
    pygame.mixer.music.play(-1, 0.0)  # Loop die Musik unendlich

    menu_running = True
    while menu_running:
        screen.fill(BLACK)
        background = pygame.image.load("C:/Schule/PO/pacman/ghggh.png")
        background = pygame.transform.scale(background, (WIDTH, HEIGHT))
        screen.blit(background, (0, 0))

        font = pygame.font.Font(None, 74)
        title_text = font.render("Fortnite", True, WHITE)
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 4))

        play_button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2, 300, 60)
        quit_button = pygame.Rect(WIDTH // 2 - 150, HEIGHT // 2 + 100, 300, 60)

        pygame.draw.rect(screen, GREEN, play_button)
        pygame.draw.rect(screen, RED, quit_button)

        font_small = pygame.font.Font(None, 48)
        play_text = font_small.render("Play", True, BLACK)
        quit_text = font_small.render("End", True, BLACK)

        screen.blit(play_text, (WIDTH // 2 - play_text.get_width() // 2, HEIGHT // 2 + 15))
        screen.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT // 2 + 115))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if play_button.collidepoint(event.pos):
                    pygame.mixer.music.stop()  # Stoppe Musik, wenn "Play" geklickt wird
                    return "play"
                if quit_button.collidepoint(event.pos):
                    pygame.quit()
                    sys.exit()

miku_playing = False  # Variable, um zu überprüfen, ob Miku-Musik schon läuft

def game_loop():
    global pacman_pos
    global miku_playing  # Stelle sicher, dass wir diese Variable verwenden
    clock = pygame.time.Clock()
    running = True
    game_over = False
    pacman_speed = [0, 0]  # Initialisiere pacman_speed innerhalb der Schleife
    pacman_direction = "right"  # Initiale Richtung von Pacman

    # Musik im Spiel starten
    pygame.mixer.music.load("C:/Schule/PO/pacman/gamemusic.mp3")
    pygame.mixer.music.play(-1, 0.0)  # Loop die Musik unendlich

    pacman_animation_index = 0  # Animationsindex für Pacman
    animation_timer = 0  # Timer für die Animation (Zeitabstände)
    animation_delay = 1  # Wie viele Frames zwischen den Animationen (je niedriger, desto schneller)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_UP, pygame.K_w):
                    pacman_speed = [0, -1]
                    pacman_direction = "up"  # Pacman bewegt sich nach oben
                if event.key in (pygame.K_DOWN, pygame.K_s):
                    pacman_speed = [0, 1]
                    pacman_direction = "down"  # Pacman bewegt sich nach unten
                if event.key in (pygame.K_LEFT, pygame.K_a):
                    pacman_speed = [-1, 0]
                    pacman_direction = "left"  # Pacman bewegt sich nach links
                if event.key in (pygame.K_RIGHT, pygame.K_d):
                    pacman_speed = [1, 0]
                    pacman_direction = "right"  # Pacman bewegt sich nach rechts
                if event.key == pygame.K_ESCAPE:
                    running = False

        if not game_over:
            new_pos = [pacman_pos[0] + pacman_speed[0], pacman_pos[1] + pacman_speed[1]]
            if level[new_pos[1]][new_pos[0]] != 2:
                pacman_pos = new_pos

            if level[pacman_pos[1]][pacman_pos[0]] == 1:
                level[pacman_pos[1]][pacman_pos[0]] = 0

            for enemy in enemies:
                direction = enemy_AI(enemy, mode=enemy["mode"])
                enemy_new_pos = [enemy["pos"][0] + direction[0], enemy["pos"][1] + direction[1]]
                if level[enemy_new_pos[1]][enemy_new_pos[0]] != 2:
                    enemy["pos"] = enemy_new_pos

                if pacman_pos == enemy["pos"]:
                    game_over = True

            if all(cell != 1 for row in level for cell in row):
                game_over = True

        screen.fill(BLACK)

        # Level zeichnen
        for y in range(len(level)):
            for x in range(len(level[y])):
                if level[y][x] == 2:
                    pygame.draw.rect(screen, BLUE, (x * CHAR_SIZE, y * CHAR_SIZE, CHAR_SIZE, CHAR_SIZE))
                elif level[y][x] == 1:
                    pygame.draw.circle(screen, WHITE, (x * CHAR_SIZE + CHAR_SIZE // 2, y * CHAR_SIZE + CHAR_SIZE // 2), 5)

        # Mundanimation von Pacman
        animation_timer += 1
        if animation_timer >= animation_delay:
            pacman_animation_index = (pacman_animation_index + 1) % len(pacman_sprites[pacman_direction])
            animation_timer = 0

        # Pacman zeichnen mit Animation
        pacman_sprite = pacman_sprites[pacman_direction][pacman_animation_index]
        screen.blit(pacman_sprite, (pacman_pos[0] * CHAR_SIZE, pacman_pos[1] * CHAR_SIZE))

        # Gegner zeichnen mit Animation, aber nur, wenn das Spiel noch nicht vorbei ist
        if not game_over:
            for enemy in enemies:
                direction = enemy_AI(enemy, mode=enemy["mode"])  # Get the movement direction
                enemy_facing = get_enemy_facing(direction)  # Get the correct facing direction
                screen.blit(enemy_sprites[enemy_facing], (enemy["pos"][0] * CHAR_SIZE, enemy["pos"][1] * CHAR_SIZE))

        if game_over:
            # Wenn Miku-Musik noch nicht läuft, starte sie
            if not miku_playing:
                pygame.mixer.music.stop()
                pygame.mixer.music.load("C:/Schule/PO/pacman/miku.mp3")
                pygame.mixer.music.play(0, 0.0)  # Spielt Miku-Musik einmalig
                miku_playing = True  # Setze miku_playing auf True, damit die Musik nicht erneut abgespielt wird

            # Miku-Bild anzeigen
            miku_image = pygame.image.load("C:/Schule/PO/pacman/miku.png")
            miku_image = pygame.transform.scale(miku_image, (WIDTH, HEIGHT))
            screen.blit(miku_image, (0, 0))

            font = pygame.font.Font(None, 74)
            text = font.render("Game Over", True, RED)
            screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - text.get_height() // 2))

        pygame.display.flip()
        clock.tick(6)

# Hauptmenü starten
if main_menu() == "play":
    game_loop()

pygame.quit()
sys.exit()
